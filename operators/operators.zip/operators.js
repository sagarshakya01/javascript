// 1. Arithmetic Operators
// Write a JavaScript program to perform the following operations. Store the results in variables and log them to the console

// let result = 12 + 8;
// console.log(result , typeof result );

// let a = 20 - 5;
// console.log(a , typeof a);

// let b = 6 * 7;
// console.log(b , typeof b);

// let c = 24 / 4;
// console.log(c , typeof c);

// let remainder = 29 % 6 ;
// console.log(remainder , typeof remainder);

// 2. Comparison Operators
// Write a program to compare the following pairs of values using comparison operators (==, ===, !=, !==, <, <=, >, >=). Print the result (true or false) for each comparison.

// let a = 5;
// let b = 10;

// if (a==b){
//     console.log("true")
// }else{
//     console.log("false");

// }
// if (a===b){
//     console.log("true");
// }else{
//     console.log("false");

// }
// if(a!=b){
//     console.log("true");
// }else{
//     console.log("false")
// }
// if (a!==b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a<b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// if(a<=b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if(a>b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a>=b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// let a ="10";
// let b = 10;

// if (a==b){
//         console.log("true")
// }else{
//         console.log("false");

//     }
// if (a===b){
//     console.log("true");
// }else{
//     console.log("false");

// }
// if(a!=b){
//     console.log("true");
// }else{
//     console.log("false")
// }
// if (a!==b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a<b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// if(a<=b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if(a>b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a>=b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// let a = false;
// let b = 0;

// if (a==b){
//     console.log("true")
// }else{
//     console.log("false");

// }
// if (a===b){
//     console.log("true");
// }else{
//     console.log("false");

// }
// if(a!=b){
//     console.log("true");
// }else{
//     console.log("false")
// }
// if (a!==b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a<b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// if(a<=b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if(a>b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a>=b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// let a = true;
// let b = 1;

// if (a==b){
//     console.log("true")
// }else{
//     console.log("false");

// }
// if (a===b){
//     console.log("true");
// }else{
//     console.log("false");

// }
// if(a!=b){
//     console.log("true");
// }else{
//     console.log("false")
// }
// if (a!==b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a<b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// if(a<=b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if(a>b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a>=b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// let a = undefined;
// let b = null;

// if (a==b){
//     console.log("true")
// }else{
//     console.log("false");

// }
// if (a===b){
//     console.log("true");
// }else{
//     console.log("false");

// }
// if(a!=b){
//     console.log("true");
// }else{
//     console.log("false")
// }
// if (a!==b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a<b){
//     console.log("true")
// }else{
//     console.log("false")
// }

// if(a<=b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if(a>b){
//     console.log("true")
// }else{
//     console.log("false")
// }
// if (a>=b){
//     console.log("true")
// }else{
//     console.log("false")
// }



// 3. Logical Operators
// Evaluate the following logical expressions using the logical operators (&&, ||, !). Log the result to the console.


// console.log((5 > 3) && (8 > 12));
// console.log((7 === "7") || (3 === 3));
// console.log(!(true && false));
// console.log((false || true) && !(3 > 5));


// 4. Assignment Operators
// Initialize the variable x with the value 10. Perform the following operations using assignment operators and print the results.

// let a = 5;
// a +=10;
// console.log(a);

// let a = 10;
// a -=4;
// console.log(a);

// let a = 2;
// a *= 5;
// console.log(a);


// let a = 20;
// a /=4;
// console.log(a);

// let a = 55;
// a %= 2;
// console.log(a);



// 5. Ternary Operator
// Write a program to check whether a number is even or odd using the ternary operator. Print "Even" if the number is even and "Odd" if the number is odd.

// let number = 25;

// console.log(number % 2 === 0 ? "Even" : "Odd"); 

// let number = 24;
// console.log(number % 2 === 0 ? "Even" : "Odd");



// 6. Optional Challenge: Operator Precedence
// Consider the following expression and evaluate it step-by-step based on operator precedence. Log the final result.

// let result = 10 + 5 * 2 - (3 / 3) + 8;
// console.log(result); 

// let result = 10 + 10 - (4 / 4 ) + 4 * 2;
// console.log(result);


// 7. Increment and Decrement Operators
// Create a program that initializes a variable count with the value 10. Perform the following operations using increment (++) and decrement (--) operators. Log the results after each operation:

// Pre-increment the variable and log the value.
// Post-increment the variable and log the value.
// Pre-decrement the variable and log the value.
// Post-decrement the variable and log the value.


// let count = 10;
// console.log(++count);

// let count = 10;
// console.log(count++);
// console.log(count);

// let count = 10;
// console.log(--count);

// let count = 10;
// console.log(count--);
// console.log(count);


// 9. Compound Logical Operators
// Given the following variables:

// let a = true;
// let b = false;
// let c = true;

// console.log(a && b || c); ##############################################################

// console.log((a || b) && !c);

// console.log(a && (b || c) && !b);

// console.log(!a || !b || !c);


// 10. Combining Different Operators
// Write a program that combines arithmetic, comparison, logical, and assignment operators in a single expression. Evaluate and log the result of the following expression:

let x = 5;
let y = 10;
let result = (x + y * 2 > 20) && (x += 5) || (y -= 3);
console.log(result); 
